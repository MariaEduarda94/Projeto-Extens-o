function abrirNovaSenha() {
    window.location.href ="nova-senha.html";
}
function abrirIndex(){
    window.location.href = "index.html";
}
function cadMotorista(){
    nomeMotorista = document.getElementById("name-driver").value;
}

function abrirHome(){
    window.location.href = "home.html";
}
function abrirCadastrarMotorista(){
    window.location.href = "cadastrar-motorista.html";
}