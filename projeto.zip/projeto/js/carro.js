class Carro{
    constructor(nome, montadora, placa, anoFabricacao){
        this.nome = nome;
        this.montadora = montadora;
        this.placa = placa;
        this.anoFabricacao = anoFabricacao;
    }
}