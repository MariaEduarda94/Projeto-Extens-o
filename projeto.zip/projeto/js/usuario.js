class Usuario{
    constructor(nome, cpf, email, dataNascimento){
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.dataNascimento = dataNascimento;
    }
}