class Motorista{
    constructor(nome, cnh, telefone, cep, dataNascimento){
        this.nome = nome;
        this.cnh = cnh;
        this.telefone = telefone;
        this.cep = cep;
        this.dataNascimento = dataNascimento;
    }
}
export default Motorista;